package com.eukon05;

import com.google.gson.Gson;

import java.io.*;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.HashMap;
import java.util.Map;

public class Main {

    private final static File home = new File(System.getProperty("user.dir") + File.separator + "home");
    private final static File dev = new File(System.getProperty("user.dir") + File.separator + "dev");
    private final static File test = new File(System.getProperty("user.dir") + File.separator + "test");
    private final static Map<String, Integer> countMap = new HashMap<>();
    private final static Gson gson = new Gson();
    private static WatchService watchService;
    private static PrintWriter count;

    public static void main(String[] args) throws IOException, InterruptedException {
        home.mkdirs();
        dev.mkdirs();
        test.mkdirs();

        countMap.put("dev", dev.listFiles().length);
        countMap.put("test", test.listFiles().length);

        count = new PrintWriter(home.getPath() + File.separator + "count.txt");
        printToCount();

        watchService = FileSystems.getDefault().newWatchService();

        Paths.get(home.getPath()).register(watchService, StandardWatchEventKinds.ENTRY_CREATE);

        WatchKey watchKey;

        while ((watchKey = watchService.take()) != null) {
            for (WatchEvent<?> event : watchKey.pollEvents()) {
                int creationHour = LocalDateTime.ofInstant(Files
                        .readAttributes(Paths.get(home.getPath() + File.separator + event.context().toString()), BasicFileAttributes.class)
                        .creationTime()
                        .toInstant(), ZoneId.systemDefault())
                        .getHour();

                switch (event.context().toString().substring(event.context().toString().lastIndexOf(".")+1)){
                    case "jar":{
                        if(creationHour%2==0){
                            moveFile(event, dev);
                        }
                        else {
                            moveFile(event, test);
                        }
                        break;
                    }
                    case "xml":{
                        moveFile(event, dev);
                        break;
                    }
                    default:{
                        System.out.println("file with an unknown extension added to HOME");
                        break;
                    }
                }
            }
            watchKey.reset();
        }

    }

    private static void printToCount(){
        count.println(gson.toJson(countMap));
        count.flush();
    }

    private static void moveFile(WatchEvent event, File folder){
        try {
            Files.move(Paths.get(home.getPath() + File.separator + event.context().toString()), Paths.get(folder.getPath() + File.separator + event.context().toString()));
            countMap.put(folder.getName(), folder.listFiles().length);
            printToCount();
        }
        catch (IOException ex){
            System.out.println("File already exists!");
        }
    }
}