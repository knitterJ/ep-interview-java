This app requires Java 17 <br><br>
You need to have Maven installed on your machine in order to build and run it.

How to run the app:
- Download the source code and extract it
- Go into the folder with the source code and launch a terminal there
- Run `mvn package`
- `cd` into the newly created `target` folder
- Run `java -jar fileWatcher-jar-with-dependencies.jar`